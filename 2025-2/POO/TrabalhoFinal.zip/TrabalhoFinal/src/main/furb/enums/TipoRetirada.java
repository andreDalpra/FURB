package main.furb.enums;

public enum TipoRetirada {
    VENDA_AO_CLIENTE,
    USO_INTERNO,
    DEVOLUCOES,
    OUTROS
}
