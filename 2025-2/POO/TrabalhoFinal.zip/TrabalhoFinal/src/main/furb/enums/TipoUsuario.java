package main.furb.enums;

public enum TipoUsuario {
   ADM, NORMAL, ESTAGIO
}
