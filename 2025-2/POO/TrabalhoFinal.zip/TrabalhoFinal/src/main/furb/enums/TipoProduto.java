package main.furb.enums;

public enum TipoProduto {
	HARDWARE, PERIFÉRICOS, ACESSÓRIOS, OUTROS
}
