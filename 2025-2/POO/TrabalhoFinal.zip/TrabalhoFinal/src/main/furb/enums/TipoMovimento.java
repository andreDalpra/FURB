package main.furb.enums;

public enum TipoMovimento {
    ENTRADA, SAIDA
}
