package main.furb.enums;

public enum TipoMensagem {
	OK, WARNING, ERROR
}
